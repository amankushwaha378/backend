
import pg from "pg";
import dotenv from "dotenv";

dotenv.config();

const { Pool } = pg;

const testPool = new Pool({
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT || 5432),
  user: process.env.DB_USER || "postgres",
  password: process.env.DB_PASSWORD,
  database: "blog_api_test",
});

export default testPool;
